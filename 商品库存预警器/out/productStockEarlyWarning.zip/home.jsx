//#import Util.js

(function () {
    var merchantId = $.params["m"];

    response.sendRedirect("pages/home.jsx?m=" + merchantId);
})();

