//#import Util.js

(function () {
    var merchantId = $.params["m"];


    response.sendRedirect("ProductList.jsx?m=" + merchantId + "&t=emptyStock");
})();

