//#import Util.js

(function () {

    var merchantId = $.params["m"];
    response.sendRedirect("jExportList.jsx?m=" + merchantId);
})();


