//#import Util.js

(function () {

  var merchantId = $.params["m"];
  response.sendRedirect("pages/RecordList.jsx?m=" + merchantId);
})();