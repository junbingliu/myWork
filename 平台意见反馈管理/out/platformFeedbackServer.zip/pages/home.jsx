//#import Util.js

(function () {

    var merchantId = $.params["m"];
    response.sendRedirect("RecordList.jsx?m=" + merchantId);
})();

