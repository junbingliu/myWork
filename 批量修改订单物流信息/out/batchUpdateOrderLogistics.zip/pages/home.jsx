//#import Util.js

(function () {
    var merchantId = $.params["m"] || "head_merchant";


    response.sendRedirect("BatchForm.jsx?m=" + merchantId);
})();

