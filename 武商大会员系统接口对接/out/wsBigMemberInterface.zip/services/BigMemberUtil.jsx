//#import Util.js

var BigMemberUtil = (function () {

    var f = {
        saveMemberId2UserId: function (memberId, userId) {

        }
    };
    return f;
})();