//#import Util.js

(function(){
    var scanCode = $.getUUID();
    out.print(scanCode);
})();