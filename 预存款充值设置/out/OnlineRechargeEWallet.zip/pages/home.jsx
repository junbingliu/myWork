//#import Util.js

(function () {

    var merchantId = $.params["m"];

    response.sendRedirect("ArgsForm.jsx?m=" + merchantId);
})();

